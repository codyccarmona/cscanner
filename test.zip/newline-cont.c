// Example 
// Program 
/*
alkjnf 

*/
main()
{
   printf("This is a test with cont\
inuation.\"");
}
